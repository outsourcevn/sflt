﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SearchFilter
{
    public class Config
    {
        public static string query(string from,string to,string type,int col) { 
            string query="SELECT F"+col+" as name FROM  list where 1=1 ";
            if (from!=null && from!=""){
                query+=" and F2 like N'"+from+"' ";
            }
            if (to!=null && to!=""){
                query+=" and F3 like N'"+to+"' ";
            }
            if (type!=null && type!=""){
                query+=" and F4 like N'"+type+"' ";
            }
            query+=" group by F"+col;
            return query;
        }
    }
}